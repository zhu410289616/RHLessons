//
//  main.m
//  test
//
//  Created by Vincent DU on 15/8/3.
//  Copyright (c) 2015年 Vincent DU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

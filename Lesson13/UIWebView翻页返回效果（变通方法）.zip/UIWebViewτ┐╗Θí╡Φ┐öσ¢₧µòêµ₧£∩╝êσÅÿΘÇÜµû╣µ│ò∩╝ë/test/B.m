//
//  B.m
//  test
//
//  Created by Vincent DU on 15/8/3.
//  Copyright (c) 2015年 Vincent DU. All rights reserved.
//

#import "B.h"

@interface B ()

@end

@implementation B
@synthesize objUrl;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets=NO;//防止滚动类头部出现空行
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        self.navigationController.interactivePopGestureRecognizer.delegate = (id<UIGestureRecognizerDelegate>)self;
    }
    NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:objUrl]];
    //NSLog(@"网址：%@",objUrl);
    [webView setDataDetectorTypes:UIDataDetectorTypePhoneNumber];
    [webView setUserInteractionEnabled:YES]; //是否支持交互
    [webView loadRequest:request];
    [self.view addSubview: webView];
    [webView setDelegate:self];
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if(navigationType==UIWebViewNavigationTypeLinkClicked)//判断是否是点击链接
    {
        UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        UIViewController *myView = [story instantiateViewControllerWithIdentifier:@"A"];
        [myView setValue:request.URL.absoluteString forKey:@"objUrl"];
        [self.navigationController pushViewController:myView animated:YES];
        return NO;
    }
    else{
        return YES;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
